

export  default function AllFilterComponent(){
    return(<div>
    <div style={{width:"100%",height:"100%",background:"plum"}}>
     <div  style={{width:"20%",height:"100px",background:"yellow"}}>
        </div>  
        </div> 
            </div>)
}