// import { keyframes } from '@emotion/react';
// import Box from '@mui/material/Box';







// export default function Image(){
//     return (<div style={{ className=div,className= keyframes}}>
//           <Box
//         sx={{
//           width: 100,
//           height: 100,
//           borderRadius: 1,
//           bgcolor: 'primary.main',
//           '&:hover': {
//             bgcolor: 'primary.dark',
//           },
//         }}
//       />
//     </div>)

// }